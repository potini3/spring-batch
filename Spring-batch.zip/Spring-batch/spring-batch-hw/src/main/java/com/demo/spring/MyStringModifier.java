package com.demo.spring;

import java.util.List;

import org.springframework.batch.item.ItemProcessor;


public class MyStringModifier implements ItemProcessor<String, String> {

	@Override
	public String process(String item) throws Exception {
		
		System.out.println("Processing...."+item);
		return item+"Processed";
	}
	
		
	}

	
	
	
	

